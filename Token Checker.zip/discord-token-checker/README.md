# Discord-token-checker
## With this tool you can check whether a discord token has a payment method and the general info about it **USE PYTHON VERSION 3.9**
# Installation 
```
Run Install.bat to install the requirements
Go to the tokens.txt and put your tokens that you want to check
Run main.py and let it check the tokens!
```
![CHECKERPREVIEW](https://media.discordapp.net/attachments/1037600501543485491/1042141290009202818/image.png?width=1440&height=684)
